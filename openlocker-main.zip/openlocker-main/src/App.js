// src/App.js
import React from 'react';
import LockerControl from './components/LockerControl';

function App() {
  return (
    <div className="App">
      <LockerControl />
    </div>
  );
}

export default App;
